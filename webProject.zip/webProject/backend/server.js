// WebProject/backend/server.js

const express = require('express');
const mysql = require('mysql2/promise'); // Promise tabanlı kullanımı tercih ediyoruz
const cors = require('cors'); // Frontend erişimi için gerekli olabilir
const app = express();
const PORT = 5000;

// Middleware'ler
app.use(express.json());
app.use(cors()); // Tüm originlerden gelen isteklere izin verir (Geliştirme için uygundur)

// --- Veritabanı Bağlantı Havuzu (Pool) ---
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};
const pool = mysql.createPool(dbConfig);

// --- Yardımcı Fonksiyon: Matematiksel Kuralları Doğrulama ---
function validatePhoneNumber(numberStr) {
    // Kural 1: Format Kontrolü (6 basamaklı sayı)
    if (!/^\d{6}$/.test(numberStr)) {
        return { rules: null, isValid: false, message: "Hatalı Format: Numara 6 basamaklı olmalı ve sadece rakam içermelidir." };
    }

    const a = numberStr.split('').map(Number); // [a1, a2, a3, a4, a5, a6]

    // Kural 2: En az bir sıfırdan farklı rakam
    const hasNonZeroDigit = a.some(digit => digit !== 0);

    // Kural 3: İlk üç = Son üç
    const sumFirstEqualsLast = (a[0] + a[1] + a[2]) === (a[3] + a[4] + a[5]);

    // Kural 4: Tek sıra = Çift sıra
    const sumOddEqualsEven = (a[0] + a[2] + a[4]) === (a[1] + a[3] + a[5]);

    const isValid = hasNonZeroDigit && sumFirstEqualsLast && sumOddEqualsEven;

    const rulesMet = {
        hasNonZeroDigit: hasNonZeroDigit,
        sumFirstEqualsLast: sumFirstEqualsLast,
        sumOddEqualsEven: sumOddEqualsEven
    };

    return { rules: rulesMet, isValid: isValid, message: isValid ? "Başarılı" : "Geçersiz Numara" };
}

// --- DB Başlangıç Tablo Oluşturma ---
async function initializeDB() {
    try {
        const connection = await pool.getConnection();
        await connection.execute(`
            CREATE TABLE IF NOT EXISTS registrations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(150) NOT NULL,
                phone CHAR(6) NOT NULL UNIQUE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        connection.release();
        console.log("MySQL tablosu başarıyla oluşturuldu/kontrol edildi.");
    } catch (error) {
        console.error("Veritabanı başlatma hatası:", error.message);
        // Hata durumunda uygulamanın başlamasını engellemek isteyebilirsiniz.
        // process.exit(1); 
    }
}

// --- Endpoint 1: Telefon Numarası Doğrulama ---
app.post('/api/phone/validate', (req, res) => {
    const { number } = req.body;

    if (!number) {
        return res.status(400).json({ error: "Numara gerekli." });
    }

    const { rules, isValid, message } = validatePhoneNumber(number);

    if (rules === null) { // Hatalı format
        return res.status(400).json({ error: message });
    }

    return res.json({
        number: number,
        rules: rules,
        isValid: isValid
    });
});

// --- Endpoint 2: Kullanıcı Kaydı ---
app.post('/api/registration', async (req, res) => {
    const { name, email, phone } = req.body;

    if (!name || !email || !phone) {
        return res.status(400).json({ status: "error", message: "Eksik bilgi: İsim, e-posta ve telefon gerekli." });
    }

    // Doğrulama
    const validation = validatePhoneNumber(phone);

    if (!validation.isValid) {
        return res.status(422).json({
            status: "denied",
            message: "Geçersiz telefon numarası. Lütfen yeni bir numara deneyin.",
            isValid: false
        });
    }

    // Veritabanına Kayıt
    let connection;
    try {
        connection = await pool.getConnection();
        const insertQuery = "INSERT INTO registrations (name, email, phone) VALUES (?, ?, ?)";
        const [result] = await connection.execute(insertQuery, [name, email, phone]);
        const userId = result.insertId;

        // Yeni kaydı çekme
        const [rows] = await connection.execute("SELECT id, name, email, phone, created_at FROM registrations WHERE id = ?", [userId]);
        const newRecord = rows[0];

        // created_at alanını ISO formatına çevir
        if (newRecord && newRecord.created_at) {
            newRecord.createdAt = newRecord.created_at.toISOString().replace('T', ' ').substring(0, 19);
            delete newRecord.created_at;
        }

        res.status(201).json({
            status: "accepted",
            message: "Telefon numarası geçerli, kayıt başarıyla oluşturuldu.",
            data: newRecord
        });

    } catch (error) {
        // MySQL Duplicate Entry Error (ER_DUP_ENTRY) - UNIQUE constraint ihlali
        if (error.errno === 1062) {
            return res.status(409).json({
                status: "denied",
                message: `Telefon numarası zaten kayıtlı: ${phone}`,
                isValid: false
            });
        }
        console.error("Veritabanı kayıt hatası:", error.message);
        res.status(500).json({ status: "error", message: "Kayıt sırasında bir sunucu hatası oluştu." });
    } finally {
        if (connection) connection.release();
    }
});

// --- Endpoint 3: Geçerli Numara Sayısı (Algoritmik Hesaplama) ---
app.get('/api/phone/count', (req, res) => {
    // N(S) değerleri (İki rakamın toplamının S olma sayısı, S: 0-18)
    const N_S = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
    
    // Geçerli numaralar: a5 = a2 ve a1 + a3 = a4 + a6.
    // Sum of squares: N(S)^2 toplamı
    const sumOfSquares = N_S.reduce((sum, n) => sum + n * n, 0); // Bu toplam 333'tür.
    
    // Kural 2 ve 3'e uyan toplam numara sayısı = sum_of_squares * 10 (a2 ve a5 için 10 seçenek)
    const totalValidByRules2_3 = sumOfSquares * 10; // 3330
    
    // Kural 1: 000000 hariç (000000 bu iki kuralı sağlar, bu yüzden 1 çıkarmalıyız)
    const finalCount = totalValidByRules2_3 - 1; // 3329

    res.json({
        status: "success",
        totalValidNumbers: finalCount,
        calculationNote: "Total numbers satisfying a1+a3=a4+a6 and a2=a5 minus '000000'."
    });
});


// --- Opsiyonel: Tüm Kayıtları Listeleme (Frontend Bonus için) ---
app.get('/api/registrations', async (req, res) => {
    let connection;
    try {
        connection = await pool.getConnection();
        const [rows] = await connection.execute("SELECT id, name, email, phone, created_at FROM registrations ORDER BY id DESC LIMIT 20");
        
        const records = rows.map(record => ({
            id: record.id,
            name: record.name,
            email: record.email,
            phone: record.phone,
            // created_at'ı ISO formatına çevir
            createdAt: record.created_at ? record.created_at.toISOString().replace('T', ' ').substring(0, 19) : null 
        }));

        res.json({ status: "success", data: records });

    } catch (error) {
        console.error("Kayıt listeleme hatası:", error.message);
        res.status(500).json({ status: "error", message: "Kayıtlar çekilemedi." });
    } finally {
        if (connection) connection.release();
    }
});


// --- Uygulamayı Başlatma ---
initializeDB().then(() => {
    app.listen(PORT, () => {
        console.log(`Backend API çalışıyor: http://localhost:${PORT}`);
    });
});