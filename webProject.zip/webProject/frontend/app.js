// WebProject/frontend/app.js

// Backend API'nin Docker Network içindeki adresi ve portu
// Frontend container'ı (Nginx), bu adresi kullanarak Backend container'ına ulaşır.
const API_BASE_URL = 'http://localhost:5001/api';

document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    submitRegistration();
});

// Kayıt formunu gönderme işlevi
async function submitRegistration() {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const messageDiv = document.getElementById('message');

    // Telefon numarasını temizleyip 6 basamak kontrolü
    if (!/^\d{6}$/.test(phone)) {
        displayMessage("Lütfen 6 basamaklı geçerli bir telefon numarası girin.", 'denied');
        return;
    }

    const data = { name, email, phone };
    messageDiv.className = 'error';
    messageDiv.textContent = 'İşleniyor...';

    try {
        const response = await fetch(`${API_BASE_URL}/registration`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();

        if (response.status === 201 && result.status === 'accepted') {
            displayMessage(`Kayıt başarılı: ${result.message}`, 'success');
            // Formu temizle
            document.getElementById('registrationForm').reset(); 
            // Kayıt listesini güncelle
            await fetchRegistrations();
        } else if (response.status === 422 || response.status === 409) {
            // Geçersiz numara veya zaten kayıtlı
            displayMessage(`Kayıt reddedildi: ${result.message}`, 'denied');
        } else {
            // Diğer hatalar (400, 500 vb.)
            displayMessage(`Bir hata oluştu: ${result.message || 'Sunucu hatası.'}`, 'error');
        }

    } catch (error) {
        console.error('API İsteği Başarısız:', error);
        // Genellikle burada tarayıcı CORS hatası (ya da network hatası) alırsınız.
        displayMessage('Sunucuya veya API’ye ulaşılamıyor. (Network/CORS Hatası)', 'error');
    }
}

// Mesaj gösterme işlevi
function displayMessage(text, type) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = text;
    messageDiv.className = type; // success, denied, error
}

// Kayıt listesini çekme işlevi (Bonus)
async function fetchRegistrations() {
    const tableBody = document.getElementById('registrationTableBody');
    const countInfoDiv = document.getElementById('count-info');
    tableBody.innerHTML = '<tr><td colspan="3">Yükleniyor...</td></tr>';

    try {
        // Kayıtları çek
        const regResponse = await fetch(`${API_BASE_URL}/registrations`);
        const regResult = await regResponse.json();

        // Toplam geçerli numara sayısını çek
        const countResponse = await fetch(`${API_BASE_URL}/phone/count`);
        const countResult = await countResponse.json();
        
        // Numara sayısını göster
        if (countResult.status === 'success') {
             countInfoDiv.textContent = `Toplam geçerli farklı numara sayısı: ${countResult.totalValidNumbers}`;
        }

        if (regResult.status === 'success' && regResult.data.length > 0) {
            tableBody.innerHTML = regResult.data.map(item => `
                <tr>
                    <td>${item.name}</td>
                    <td>${item.phone}</td>
                    <td>${new Date(item.createdAt).toLocaleString()}</td>
                </tr>
            `).join('');
        } else {
            tableBody.innerHTML = '<tr><td colspan="3">Henüz kayıt yok.</td></tr>';
        }

    } catch (error) {
        console.error('Kayıtlar çekilemedi:', error);
        tableBody.innerHTML = '<tr><td colspan="3">Kayıtlar yüklenirken bir hata oluştu.</td></tr>';
        countInfoDiv.textContent = 'Toplam numara sayısı bilgisi çekilemedi.';
    }
}

// Sayfa yüklendiğinde kayıtları çek
document.addEventListener('DOMContentLoaded', fetchRegistrations);